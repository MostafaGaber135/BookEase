import React from 'react'

export default function MyBooking() {
    return (
        <div>MyBooking</div>
    )
}
