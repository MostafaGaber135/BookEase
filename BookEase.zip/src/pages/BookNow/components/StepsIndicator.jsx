import React from "react";
import { FaCheck } from "react-icons/fa";

export default function StepsIndicator({ currentStep }) {
  const steps = ["Select Service", "Choose Date & Time", "Your Details", "Confirmation"];

  return (
    <div className="w-full">
      <div className="hidden md:flex w-full items-center justify-between">
        {steps.map((label, index) => {
          const step = index + 1;
          const isActive = step === currentStep;
          const isCompleted = step < currentStep;

          return (
            <div key={label} className="flex-1 flex items-center min-w-0">
              <div
                className={`
                  w-9 h-9 lg:w-10 lg:h-10 rounded-full flex items-center justify-center font-semibold shrink-0
                  ${isCompleted ? "bg-[#2ec2b3] text-white" : ""}
                  ${isActive && !isCompleted ? "bg-[#2ec2b3] text-white" : ""}
                  ${!isActive && !isCompleted ? "bg-gray-100 text-gray-500" : ""}
                `}
              >
                {isCompleted ? <FaCheck className="text-sm" /> : step}
              </div>

              <span
                className={`
                  ml-2 lg:ml-3 text-xs lg:text-sm font-medium truncate
                  ${isActive || isCompleted ? "text-[#1d2930]" : "text-gray-500"}
                `}
                title={label}
              >
                {label}
              </span>

              {index !== steps.length - 1 && (
                <div className="flex-1 mx-2 lg:mx-4 h-px bg-gray-200">
                  <div className={`h-px ${isCompleted ? "bg-[#2ec2b3]" : "bg-transparent"}`} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="md:hidden">
        <div className="overflow-x-auto pb-2 [-webkit-overflow-scrolling:touch]">
          <div className="flex gap-3 min-w-max px-1">
            {steps.map((label, index) => {
              const step = index + 1;
              const isActive = step === currentStep;
              const isCompleted = step < currentStep;

              return (
                <div
                  key={label}
                  className={`
                    shrink-0 flex items-center gap-2
                    rounded-full border
                    px-3 py-2
                    ${isActive ? "border-[#2ec2b3] bg-[#eaf9f8]" : "border-[#e2e9e9] bg-white"}
                  `}
                >
                  <div
                    className={`
                      w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm shrink-0
                      ${isCompleted ? "bg-[#2ec2b3] text-white" : ""}
                      ${isActive && !isCompleted ? "bg-[#2ec2b3] text-white" : ""}
                      ${!isActive && !isCompleted ? "bg-gray-100 text-gray-500" : ""}
                    `}
                  >
                    {isCompleted ? <FaCheck className="text-[12px]" /> : step}
                  </div>

                  <span
                    className={`
                      text-sm font-medium whitespace-nowrap
                      ${isActive || isCompleted ? "text-[#1d2930]" : "text-gray-500"}
                    `}
                  >
                    {label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-2 h-1 w-full bg-gray-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#2ec2b3] transition-all"
            style={{ width: `${(currentStep / steps.length) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
}
